#!/system/bin/sh
ui_print "Installing ColorOS Forwarder KeepAlive"
ui_print "Target package: cn.ppps.forwarder"
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
