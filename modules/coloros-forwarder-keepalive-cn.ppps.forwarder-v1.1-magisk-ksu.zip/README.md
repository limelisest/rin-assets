# ColorOS Forwarder KeepAlive

Target package: `cn.ppps.forwarder`.

This Magisk/KernelSU module runs a late-start watchdog that:

- adds `cn.ppps.forwarder` to Doze whitelist;
- sets standby bucket to `active`;
- allows common background appops where supported;
- checks every 120 seconds and launches the app when its process is gone;
- also applies whitelist-only protection to WeChat `com.tencent.mm`.

It does not modify system partitions. It only runs root shell commands after boot.

Still configure ColorOS manually: allow background run, auto-start, associated/background launch, notification permission, and lock the app in recents.
Version 1.1 adds Magisk recovery-style META-INF installer files while keeping module.prop at zip root for KernelSU/Magisk app installation.
