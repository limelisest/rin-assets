#!/system/bin/sh

MODDIR=${0%/*}
LOG="$MODDIR/keepalive.log"
MAIN_PKG="cn.ppps.forwarder"
EXTRA_PKGS="com.tencent.mm"
INTERVAL_SECONDS=120

log() {
  echo "$(date '+%F %T') $*" >> "$LOG"
}

cmd_ok() {
  "$@" >/dev/null 2>&1
}

wait_boot() {
  until [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ]; do
    sleep 10
  done
  sleep 30
}

pkg_exists() {
  pm path "$1" >/dev/null 2>&1
}

protect_pkg() {
  PKG="$1"
  pkg_exists "$PKG" || {
    log "package not found: $PKG"
    return 0
  }

  # Android Doze/App Standby exemptions.
  cmd_ok cmd deviceidle whitelist +"$PKG"
  cmd_ok dumpsys deviceidle whitelist +"$PKG"
  cmd_ok am set-inactive "$PKG" false
  cmd_ok am set-standby-bucket "$PKG" active

  # Background-related appops. Some ROMs/Android versions do not have every op; ignore failures.
  cmd_ok cmd appops set "$PKG" RUN_IN_BACKGROUND allow
  cmd_ok cmd appops set "$PKG" RUN_ANY_IN_BACKGROUND allow
  cmd_ok cmd appops set "$PKG" WAKE_LOCK allow
  cmd_ok cmd appops set "$PKG" START_FOREGROUND allow
  cmd_ok cmd appops set "$PKG" POST_NOTIFICATION allow
}

is_running() {
  PKG="$1"
  pidof "$PKG" >/dev/null 2>&1 && return 0
  # Some apps use child processes such as package:service.
  pgrep -f "^$PKG(:|$)" >/dev/null 2>&1 && return 0
  return 1
}

launch_pkg() {
  PKG="$1"
  pkg_exists "$PKG" || return 0
  log "$PKG is not running; launching"
  cmd_ok monkey -p "$PKG" -c android.intent.category.LAUNCHER 1
  # If the app listens to boot/package events, these may help it re-register background workers.
  cmd_ok am broadcast -a android.intent.action.MY_PACKAGE_REPLACED -p "$PKG"
  cmd_ok am broadcast -a android.intent.action.BOOT_COMPLETED -p "$PKG"
}

wait_boot
log "ColorOS Forwarder KeepAlive started; main=$MAIN_PKG interval=${INTERVAL_SECONDS}s"

while true; do
  protect_pkg "$MAIN_PKG"
  for PKG in $EXTRA_PKGS; do
    protect_pkg "$PKG"
  done

  if ! is_running "$MAIN_PKG"; then
    launch_pkg "$MAIN_PKG"
  fi

  sleep "$INTERVAL_SECONDS"
done
