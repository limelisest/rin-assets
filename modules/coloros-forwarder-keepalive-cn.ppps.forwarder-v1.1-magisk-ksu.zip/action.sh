#!/system/bin/sh
MODDIR=${0%/*}
echo "ColorOS Forwarder KeepAlive"
echo "Main package: cn.ppps.forwarder"
echo "Log: $MODDIR/keepalive.log"
echo
if pm path cn.ppps.forwarder >/dev/null 2>&1; then
  echo "Package: installed"
else
  echo "Package: NOT installed"
fi
if pidof cn.ppps.forwarder >/dev/null 2>&1 || pgrep -f '^cn\.ppps\.forwarder(:|$)' >/dev/null 2>&1; then
  echo "Process: running"
else
  echo "Process: not running"
fi
echo
[ -f "$MODDIR/keepalive.log" ] && tail -n 20 "$MODDIR/keepalive.log"
